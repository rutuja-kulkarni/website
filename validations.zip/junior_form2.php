<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admission Form</title>
<style type="text/css">
        .upload {
            
		float:right;
        }
	.container{
	background-color:#ffe6e6;
	}
	.hr {
		background-color: red; height: 1px; border: 0; }
	}
        
    </style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="css\bootstrap.min.css">
  <script src="jquery\3.1.1/jquery.min.js"></script>
  <script src="js\bootstrap.min.js"></script>

</head>
<body>
</br></br></br></br>

<div class="container" >
  <div>
  <p>Guardian's Name:&nbsp <input type="text" name="name" size="120" required></p>
  <p>Relation with student:&nbsp <input type="text" name="name" size="50" required>&nbsp &nbsp Occupation:<input type="text" name="name" size="30" required></p>
  <p>Phone:&nbsp <input type="text" name="name" size="30" required>&nbsp &nbsp Annual income (from all sources):&nbsp &nbsp <input type="text" name="name" size="30" required></p>
  <p>No of Dependents:&nbsp &nbsp <input type="text" name="name" size="10" required>&nbsp &nbsp Guardian's Full Address: &nbsp &nbsp <input type="text" name="name" size="80" required></p>
  </hr>
  I hereby declare that the academic and personal information given by me in this application is correct and true. I hereby agree to follow the rules regarding
  study and discipline below. I futher agree to abide by the rules of discipline framed by the authorities of the college in future as well. I am folly the 
principal has full rights to take any disciplinary action against me in may best interest and shall not raise any objection against it. </br> </br>
<p class="text-right" >Your's Faithfully,</p></br>
<p class="text-right" >&nbsp &nbsp (Student's Signature)</p></br>
&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
Date:<input type="text" name="name" size="20" required>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
Mobile No.<input type="text" name="name" size="30" required>
</hr></br></br></br></br>
<h5 class="text-center"><strong>Rules Regarding Study and Discipline</strong></h5>
<p>1. Regular attendance appearance for all lectures, tests, tutorials, Practicals, Internal examinations is obligatory throughout my academic year.</p>
<p>2. Leave of absence requires prior permission form Principal or the Supervisor.</p>
<p>3. Discipline in the classroom as well as in the college campus must be maintained. The college authorities have the right to take disciplinary action against any 
kind of indiscipline of misconduct.</p>
<p>4. Guardians are expected to meet the Principal Supervisor in connection with his ward, if necessary. If the guardian does not respond, the Principal shall take 
required action against the student concerned, and guardian's complaints against such an action shall not be entertained.</p>
</hr></br></br></br></br>


<h5 class="text-center"><strong>Guardian's Consent</strong></h5>
<p> I hereby accept the rules framed and to be framed from time to time by the college authorities/Board of Higher Secondary Examinations, Maharashtra State and the Maharashtra State
Administrative Authorities. I further agree that they are binding on my ward and that in all matters the principal shall be the final authority. I am fully 
aware thet the admission given to my ward does not necessarily mean that he/she is entitled to get admission to the Senior college after passing the H.S.C. Examination.</p>
 </br></br>
<p class="text-right" >&nbsp &nbsp Guardian's Signature</p></br>
&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
Date:<input type="text" name="name" size="20" required>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
Mobile No.<input type="text" name="name" size="30" required>
</hr></br></br></br>

<h5 class="text-center"><strong>Decision by the Principal</strong></h5>
<p>Provisionally admitted until eligibility is obtained as per the rules down by the Board of Higher Secondary Examinations,Maharashtra State, Pune.</p>
</br></br> Date:<input type="text" name="name" size="20" required>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
Student's Signature &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Supervisor's Signature
</hr></br></br></br></br>

<div class="text-center">
	<input type="submit" name="subform" class="btn btn-info" value="Save">
</div>
</div>
</br>
</br>












