<!DOCTYPE html>
<html>
	<head>
	  <meta charset="utf-8"/>
	  <title>Chitamanrao College of Commerce,Sangli</title>
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="css\bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	  <script src="js\bootstrap.min.js"></script>
	</head>
	<body style="background-color:powderblue">
				<div class="container-fluid" style="margin-left:5%;margin-right:5%">
					<div class="logo" style="float:left;">
						<img src="clogo.jpg" class="img-rounded" alt="Cinque Terre" width="100" height="100">
					</div>
					<center>
						<div class="head">
							<h4 style="text-align:center;margin-top:2%">Deccan Education Society's</h4>
							<h1 style="font-style:bold;margin-left:15%">Chintamanrao College of Commerce,Sangli.</h1>
							<h4 style="text-align:center">Phone : 0233-3025200, 3025201, 601362.</h4>
						</div>
					</center>
					<nav class="navbar navbar-default" style="background-color:#b8d2fc">
						<div class="container-fluid">
							<ul class="nav navbar-nav">
								<li class="active"><a href="index.php">Home</a></li>
								<li><a href="institute.php">The institute</a></li>
								<li><a href="admissions.php">Admissions</a></li>
								<li><a href="academics.php">Academics</a></li>
								<li><a href="student.php">Student</a></li>
								<li><a href="department.php">Departments</a></li>
								<li><a href="faculty.php">Faculty</a></li>
								<li><a href="alumina.php">Alumina</a></li>
								<li><a href="contact.php">Contact</a></li>
							</ul>
						</div>
					</nav>
					<div id="myCarousel" class="carousel slide" data-ride="carousel">
					  <!-- Indicators -->
					  <ol class="carousel-indicators">
						<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
						<li data-target="#myCarousel" data-slide-to="1"></li>
						<li data-target="#myCarousel" data-slide-to="2"></li>
						<li data-target="#myCarousel" data-slide-to="3"></li>
					  </ol>

					  <!-- Wrapper for slides -->
					  <div class="carousel-inner" role="listbox">
						<div class="item active">
						  <img src="im1.jpg" alt="Chania" height="640 width="360">
						</div>

						<div class="item">
						  <img src="im2.jpg" alt="Chania" height="640 width="360">
						</div>

						<div class="item">
						  <img src="im3.jpg" alt="Flower" height="640 width="360">
						</div>

						<div class="item">
						  <img src="im4.jpg" alt="Flower" height="640 width="360">
						</div>
					  </div>

					  <!-- Left and right controls -->
					  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					  </a>
					  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					  </a>
					</div>
				</div>
				<div class="container-fluid">
					<marquee>Chintamanrao College of Commerce,Sangli</marquee>
					<marquee>Admissions are open, rush now!</marquee>
				</div>
				<div class="container-fluid left">
					<div class="panel panel-default ">
						<div class="panel-heading">From the Director</div>
						<ul>
						<li style="text-align: justify;"><a href="#">Director's Message</a></li>
						<li style="text-align: justify;"><a href="#">Director's Profile</a></li>
						<li style="text-align: justify;"><a href="#">Directorate</a></li>
						</ul>
								
					</div>
				</div>
				<div class="container-fluid left">
					<div class="panel panel-default ">
						<div class="panel-heading">From the Director</div>
						<ul>
						<li style="text-align: justify;"><a href="#">Director's Message</a></li>
						<li style="text-align: justify;"><a href="#">Director's Profile</a></li>
						<li style="text-align: justify;"><a href="#">Directorate</a></li>
						</ul>
								
					</div>
				</div>
				<div class="container-fluid left">
					<div class="panel panel-default ">
						<div class="panel-heading">From the Director</div>
						<ul>
						<li style="text-align: justify;"><a href="#">Director's Message</a></li>
						<li style="text-align: justify;"><a href="#">Director's Profile</a></li>
						<li style="text-align: justify;"><a href="#">Directorate</a></li>
						</ul>
								
					</div>
				</div>
				<div class="container-fluid right">
					<div class="panel panel-default ">
						<div class="panel-heading">From the Director</div>
						<ul>
						<li style="text-align: justify;"><a href="#">Director's Message</a></li>
						<li style="text-align: justify;"><a href="#">Director's Profile</a></li>
						<li style="text-align: justify;"><a href="#">Directorate</a></li>
						</ul>
								
					</div>
				</div>
				<div class="container-fluid right">
					<div class="panel panel-default">
						<div class="panel-heading">From the Director</div>
						<ul>
						<li style="text-align: justify;"><a href="#">Director's Message</a></li>
						<li style="text-align: justify;"><a href="#">Director's Profile</a></li>
						<li style="text-align: justify;"><a href="#">Directorate</a></li>
						</ul>
								
					</div>
				</div>
				<div class="container-fluid right">
					<div class="panel panel-default right">
						<div class="panel-heading">From the Director</div>
						<ul>
						<li style="text-align: justify;"><a href="#">Director's Message</a></li>
						<li style="text-align: justify;"><a href="#">Director's Profile</a></li>
						<li style="text-align: justify;"><a href="#">Directorate</a></li>
						</ul>
								
					</div>
				</div>
				<div class="container-fluid right">
					<iframe src="https://calendar.google.com/calendar/embed?src=lemdrojnf73vtj68sdpkn67hrs%40group.calendar.google.com&ctz=Asia/Calcutta" style="border: 0" width="200" height="200" frameborder="0" scrolling="no"></iframe>
				</div>
				<!--Footer-->
				<footer class="page-footer blue center-on-small-only">

					<!--Footer Links-->
					<div class="container-fluid">
						<div class="row">

							<!--First column-->
							<div class="col-md-6">
								<h5 class="title">Footer Content</h5>
								<p>Here you can use rows and columns here to organize your footer content.</p>
							</div>
							<!--/.First column-->

							<!--Second column-->
							<div class="col-md-6">
								<h5 class="title">Links</h5>
								<ul>
									<li><a href="#!">Link 1</a></li>
									<li><a href="#!">Link 2</a></li>
									<li><a href="#!">Link 3</a></li>
									<li><a href="#!">Link 4</a></li>
								</ul>
							</div>
							<!--/.Second column-->
						</div>
					</div>
					<!--/.Footer Links-->

					<!--Copyright-->
					<div class="footer-copyright">
						<div class="container-fluid">
							© 2017 Copyright: <a href="#">SRS Team</a>

						</div>
					</div>
					<!--/.Copyright-->

				</footer>
				<!--/.Footer-->
	</body>
</html>